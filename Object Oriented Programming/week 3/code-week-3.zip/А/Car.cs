﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace А
{
    public class Car
    {
        public string Make;
        public string Model;
        public FuelTypeEnum FuelType;
        public int Milleage;
        public int Hps;
        public double MarketPrice;
        public int Age;
    }
}
