﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A
{
    public interface IClickable
    {
        bool Contains(int x, int y);
    }
}
