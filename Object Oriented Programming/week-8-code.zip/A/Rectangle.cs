﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A
{
    public class Rectangle : IDrawable, IClickable
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }

        public void Draw(Graphics g)
        {
            Pen p = new Pen(Color.Red);
            g.DrawRectangle(p, X, Y, Width, Height);
        }

        public bool Contains(int x, int y)
        {
            return x >= X && x <= X + Width &&
                   y >= Y && y <= Y + Height;
        }
    }
}
