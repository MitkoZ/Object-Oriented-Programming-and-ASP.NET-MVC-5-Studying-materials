﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A
{
    public class Ellipse : IDrawable
    {
        public int X { get; set; }
        public int Y { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }

        public void Draw(Graphics g)
        {
            Pen p = new Pen(Color.Red);
            g.DrawEllipse(p, X, Y, Width, Height);
        }
    }
}
