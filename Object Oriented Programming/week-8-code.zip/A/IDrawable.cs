﻿using System.Drawing;

namespace A
{
    public interface IDrawable
    {
        void Draw(Graphics g);
    }
}