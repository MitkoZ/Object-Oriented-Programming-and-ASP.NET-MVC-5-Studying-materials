﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace A
{
    public partial class frmMain : Form
    {
        public List<IDrawable> items = new List<IDrawable>();

        public frmMain()
        {
            InitializeComponent();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = this.CreateGraphics();
            foreach(IDrawable item in items)
            {
                item.Draw(g);
            }
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                foreach(IDrawable item in items)
                {
                    if (item is IClickable)
                    {
                        IClickable clickableItem = (IClickable)item;
                        if (clickableItem.Contains(e.X, e.Y))
                        {
                            MessageBox.Show("There is a Rectangle here!");
                            return;
                        }
                    }
                }

                items.Add(new Rectangle()
                {
                    X = e.X,
                    Y = e.Y,
                    Width = 150,
                    Height = 150
                });
            }
            else
            {
                for (int i=0;i<items.Count;i++)
                {
                    if (items[i] is IClickable)
                    {
                        IClickable clickableItem = (IClickable)items[i];
                        if (clickableItem.Contains(e.X, e.Y))
                        {
                            items.RemoveAt(i);
                            this.Refresh();
                            return;
                        }
                    }
                }

                items.Add(new Ellipse()
                {
                    X = e.X,
                    Y = e.Y,
                    Width = 150,
                    Height = 150
                });
            }
            this.Refresh();
        }
    }
}
