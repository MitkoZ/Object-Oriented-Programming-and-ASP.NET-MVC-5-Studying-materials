﻿
namespace TestForm
{
    interface IResizable
    {
        void Resize();
    }
}
