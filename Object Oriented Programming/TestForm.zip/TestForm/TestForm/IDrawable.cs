﻿using System.Drawing;

namespace TestForm
{
    public interface IDrawable
    {
        void Draw(Graphics g);
    }
}
