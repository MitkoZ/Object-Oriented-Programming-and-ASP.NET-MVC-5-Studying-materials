﻿
namespace TestForm
{
    public interface IClicable
    {
        bool Contains(int x, int y);
    }
}
