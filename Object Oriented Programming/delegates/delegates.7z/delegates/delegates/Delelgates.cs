﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegates
{
    public delegate void MyDelegate();
    public delegate int MySumDelegate(int a, int b, int c);
    public delegate int MyNum(int a, int b);
}
