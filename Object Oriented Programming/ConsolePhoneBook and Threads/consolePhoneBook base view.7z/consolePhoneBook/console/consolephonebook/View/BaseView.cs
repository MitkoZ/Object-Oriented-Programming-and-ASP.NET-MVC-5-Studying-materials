﻿using ConsolePhonebook.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsolePhonebook.View
{
    public class BaseView
    {
       
        public void Show(BaseManagementEnum choice)
        {

            try
            {
                switch (choice)
                {
                    case BaseManagementEnum.Select:
                        {
                            GetAll();
                            break;
                        }
                    case BaseManagementEnum.View:
                        {
                            View();
                            break;
                        }
                    case BaseManagementEnum.Insert:
                        {
                            Add();
                            break;
                        }
                    case BaseManagementEnum.Update:
                        {
                            Update();
                            break;
                        }
                    case BaseManagementEnum.Delete:
                        {
                            Delete();
                            break;
                        }
                    case BaseManagementEnum.Exit:
                        {
                            return;
                        }
                }
            }
            catch (Exception ex)
            {
                Console.Clear();
                Console.WriteLine(ex.Message);
                Console.ReadKey(true);
            }
        }
       
    }
}
